// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


function RegisterUser() {
    document.getElementById('userRegister').setAttribute('style', 'display:block');
}

function Login() {
    document.getElementById('userRegister').setAttribute('style', 'display:none');
}

//document.getElementById("typeSubmit").onclick = function () {
//    document.getElementById("submitByLogout").submit();
//}