// For legacy purposes, preserve the UMD of the public API of Jitsi Meet
// external API (a.k.a. JitsiMeetExternalAPI).
module.exports = require('./external_api').default;